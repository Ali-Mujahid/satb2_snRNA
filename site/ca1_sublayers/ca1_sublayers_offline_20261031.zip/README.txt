Unzip all files and open ca1_sublayers/index.html. Full DESeq2 results are in the linked results archive.
